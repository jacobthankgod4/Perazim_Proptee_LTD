<?php
session_start();

if (!defined('LIVE')) {
    DEFINE('LIVE', false);
}
DEFINE('CONTACT_EMAIL','laresh1090@gmail.com');
//DEFINE('LIVE','true');
//require('./Administration/config.inc.php');
DEFINE('BASE_URI','C:/xampp/htdocs/pera/');
DEFINE('BASE_URL','localhost/pera/');
DEFINE('MYSQL', BASE_URI . '/Administration/mysql.inc.php');

function my_error_handler($e_number, $e_message, $e_file, $e_line ){

    $message = "<div class='jumbotron' style='color:#333;padding-left:200px;margin-left:100px;'><pre> An error occured in script '$e_file' on line $e_line:\n $e_message \n ";

    $message .=  print_r(debug_backtrace(), 1). "\n </div>";

   //$message .= "<pre>" .print_r($e_vars, 1)."</pre>\n";

   if (!LIVE) {
       echo "<div class='alert alert-danger'>" .nl2br($message). "</pre></div>";
   }else {
       error_log($message, 1, CONTACT_EMAIL, 'FROM:aadmin@andrizle.com');

       if ($e_number != E_NOTICE) {
        echo "<div class='alert alert-danger'> A system error occured we apologoze or the inconvinience</div>";
       }
   }
return true;
}

set_error_handler('my_error_handler');

function redirect_invalid_admin($check = 'admin_id', $destination = 'index.php', $protocol = 'http://'){
        if (!isset($_SESSION[$check])) {
            $url = $protocol . BASE_URL . $destination;
            header("location: $url");
            exit(); 
        }
}
function redirect_invalid_user($check = 'user_id', $destination = 'index.php', $protocol = 'http://'){
    if (!isset($_SESSION[$check])) {
        $url = $protocol . BASE_URL . $destination;
        header("location: $url");
        exit(); 
    }
}

function type_dropdown($title){

    $type = [
        'Select'=>' ',
        'Apartment'=>'apartment',
        'Duplex'=>'duplex',
    
    ];
    
if(isset($title)){
        $valuex = $title;
    }

    if ($valuex) {
            foreach ($type as $key008 => $value008) {
            
                echo '<option value="'.$value008.'"';
                if ($valuex == $value008) {
                    echo "selected";
                }
                echo '>'.$key008.'</option>';
            }
        }else{
            foreach ($type as $key009 => $value009) {
                echo '<option value="'.$value009.'">'.$key009.'</option>';
            }
        }

}

function status_dropdown($title){

    $type = [
        'Select Status'=>' ',
        'For Investment'=>'investment',
        'For Sale'=>'sale',
        'For Shortlet'=>'shortlet',        
        'For Rent'=>'rent',        
    
    ];
    
if(isset($title)){
        $valuex = $title;
    }

    if ($valuex) {
            foreach ($type as $key008 => $value008) {
            
                echo '<option value="'.$value008.'"';
                if ($valuex == $value008) {
                    echo "selected";
                }
                echo '>'.$key008.'</option>';
            }
        }else{
            foreach ($type as $key009 => $value009) {
                echo '<option value="'.$value009.'">'.$key009.'</option>';
            }
        }

}

function bed_dropdown($title){

    $type = [
        'Select'=>' ',
        "1"=>'1',
        "2"=>'2',
        "3"=>'3',
        "4"=>'4',
        "5"=>'5',
    
    ];
    
if(isset($title)){
        $valuex = $title;
    }

    if ($valuex) {
            foreach ($type as $key008 => $value008) {
            
                echo '<option value="'.$value008.'"';
                if ($valuex == $value008) {
                    echo "selected";
                }
                echo '>'.$key008.'</option>';
            }
        }else{
            foreach ($type as $key009 => $value009) {
                echo '<option value="'.$value009.'">'.$key009.'</option>';
            }
        }

}

function bath_dropdown($title){

    $type = [
        'Select'=>' ',
        "1"=>'1',
        "2"=>'2',
        "3"=>'3',
        "4"=>'4',
        "5"=>'5',
    
    ];
    
if(isset($title)){
        $valuex = $title;
    }

    if ($valuex) {
            foreach ($type as $key008 => $value008) {
            
                echo '<option value="'.$value008.'"';
                if ($valuex == $value008) {
                    echo "selected";
                }
                echo '>'.$key008.'</option>';
            }
        }else{
            foreach ($type as $key009 => $value009) {
                echo '<option value="'.$value009.'">'.$key009.'</option>';
            }
        }

}

function box($t1,$t2){

    if (in_array($t1, $t2)) {
            echo "checked";
        }else{
            
        }

}

function bank_dropdown($title){

    $type = [
         'Select Bank'=>' ',
        "Access Bank"=>"Access Bank",
        "Citibank"=>"Citibank",
        "Ecobank Nigeria"=>"Ecobank Nigeria",
        "Fidelity Bank"=>"Fidelity Bank",
        "First Bank of Nigeria"=>"First Bank of Nigeria",
        "First City Monument Bank (FCMB)"=>"First City Monument Bank (FCMB)",
        "Globus Bank"=>"Globus Bank",
        "Guaranty Trust Bank (GTBank)"=>"Guaranty Trust Bank (GTBank)",
        "Heritage Bank"=>"Heritage Bank",
        "Keystone Bank"=>"Keystone Bank",
        "Parallex Bank"=>"Parallex Bank",
        "Polaris Bank"=>"Polaris Bank",
        "Providus Bank"=>"Providus Bank",
        "Stanbic IBTC Bank"=>"Stanbic IBTC Bank",
        "Standard Chartered Bank"=>"Standard Chartered Bank",
        "Sterling Bank"=>"Sterling Bank",
        "SunTrust Bank"=>"SunTrust Bank",
        "Union Bank of Nigeria"=>"Union Bank of Nigeria",
        "United Bank for Africa (UBA)"=>"United Bank for Africa (UBA)",
        "Unity Bank"=>"Unity Bank",
        "Wema Bank"=>"Wema Bank",
        "Zenith Bank"=>"Zenith Bank",

    
    ];
    
if(isset($title)){
        $valuex = $title;
    }

    if ($valuex) {
            foreach ($type as $key008 => $value008) {
            
                echo '<option value="'.$value008.'"';
                if ($valuex == $value008) {
                    echo "selected";
                }
                echo '>'.$key008.'</option>';
            }
        }else{
            foreach ($type as $key009 => $value009) {
                echo '<option value="'.$value009.'">'.$key009.'</option>';
            }
        }

}

function gender_dropdown($title){

    $type = [
         'Select Gender'=>' ',
         "Male"=>"male",
         "Female"=>"female",

    
    ];
    
if(isset($title)){
        $valuex = $title;
    }

    if ($valuex) {
            foreach ($type as $key008 => $value008) {
            
                echo '<option value="'.$value008.'"';
                if ($valuex == $value008) {
                    echo "selected";
                }
                echo '>'.$key008.'</option>';
            }
        }else{
            foreach ($type as $key009 => $value009) {
                echo '<option value="'.$value009.'">'.$key009.'</option>';
            }
        }

}

function vat_calc($title1){

    $calculate_=(2.5/100)*$title1;

    return $calculate_;
    

}

?>