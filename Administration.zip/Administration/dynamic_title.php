<?php
if (isset($page_title)) {
    echo "$page_title";
}else {
    echo "DBMS - Login Page";
}