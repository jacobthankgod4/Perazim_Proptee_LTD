const allmenu  = document.querySelectorAll(".switch");

let switch_location = window.location.pathname;

for (let index = 0; index < allmenu.length; index++) {
    allmenu_new=allmenu[index];
    allmenu_new1 = allmenu_new.getAttribute("href");
    allmenu_new2="/pera/"+allmenu_new1;
    if (allmenu_new2==switch_location) {
        console.log(allmenu_new2);

        console.log(switch_location);
        allmenu_new.classList.add("active");
    }    
    if (switch_location=="/") {
        allmenu_new.classList.add('active');
    }  
}
